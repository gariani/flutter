// import 'package:flutter_facebook_login/flutter_facebook_login.dart' as facebook;

// mixin FacebookLogin{

//   var facebookLogin = facebook.FacebookLogin();
//   // var facebookLoginResult = await facebookLogin.

// }