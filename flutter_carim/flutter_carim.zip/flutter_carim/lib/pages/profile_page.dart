import 'dart:io';
import 'package:image/image.dart' as imagePack;
import 'package:carimbinho/core/models/contact.dart';
import 'package:carimbinho/pages/profile_edit_page.dart';
import 'package:carimbinho/pages/qr_code_page.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
//import 'package:flutter_exif_rotation/flutter_exif_rotation.dart';
//import 'package:exif/exif.dart';
//import 'package:flutter_image_compress/flutter_image_compress.dart';

class ProfilePage extends StatefulWidget {
  final Contact contact;

  ProfilePage({this.contact});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Contact contact;
  StorageReference storage;
  @override
  void initState() {
    super.initState();
    contact = widget.contact;
    storage = FirebaseStorage.instance.ref().child(contact.email);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(children: <Widget>[
        Container(
          width: 150.0,
          height: 150.0,
          child: Column(
            children: <Widget>[
              GestureDetector(
                  child: Container(
                    width: 150.0,
                    height: 150.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        image: contact.foto.isNotEmpty
                            ? FileImage(File(contact.foto))
                            : NetworkImage(
                                "https://cdn2.iconfinder.com/data/icons/solid-glyphs-volume-2/256/user-unisex-512.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  onTap: () {
                    ImagePicker.pickImage(
                            source: ImageSource.camera, imageQuality: 50)
                        .then((file) {
                      if (file == null) return;
                      setState(() async {
                        final StorageUploadTask upload = storage.putFile(
                            File(file.path),
                            StorageMetadata(
                              contentType: 'image/jpg',
                            ));

                        await upload.onComplete;

                        final tempDir =
                            await getApplicationDocumentsDirectory();

                        final pictureName =
                            tempDir.path + '/' + contact.email + '.png';

                        File fileDownlad = File(pictureName);

                        if (await fileDownlad.exists()) {
                          fileDownlad.deleteSync();

                          //File newFile = await rotateAndCompressAndSaveImage(fileDownlad);
                          
                          List<int> imageBytes = fileDownlad.readAsBytesSync();
                          fileDownlad.writeAsBytesSync(imageBytes);

                          imagePack.Image image = imagePack
                              .decodeImage(File(fileDownlad.path).readAsBytesSync());

                          File(pictureName)
                            ..writeAsBytesSync(imagePack.encodePng(image));
                          
                          setState(() {
                            contact.foto = pictureName;
                          });

                        } else {
                          final StorageReference refFile = FirebaseStorage
                              .instance
                              .ref()
                              .child(contact.email);
                          refFile.writeToFile(fileDownlad);
                          setState(() {
                            contact.foto = fileDownlad.uri.toFilePath();
                          });
                        }
                      });
                    });
                  }),
            ],
          ),
        ),
        Container(
          child: Column(
            children: <Widget>[
              const SizedBox(
                height: 30,
              ),
              Text(contact.nome ?? "",
                  style: TextStyle(
                      fontSize: 45.0,
                      color: Colors.green[900],
                      fontWeight: FontWeight.bold)),
              const SizedBox(
                height: 10,
              ),
              Text(
                'Membro desde ${contact.membroDesde}',
                style: TextStyle(color: Colors.green[900]),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                contact.email ?? "",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                    color: Colors.green[900]),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                contact.nomeCompleto ?? "",
                style: TextStyle(fontSize: 15.0, color: Colors.green[900]),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                contact.fone ?? "",
                style: TextStyle(color: Colors.green[900]),
              ),
              const SizedBox(
                height: 30,
              ),
            ],
          ),
        ),
        QrCodePage(data: contact.email),
        Expanded(
            flex: 1,
            child: Align(
              alignment: FractionalOffset.bottomCenter,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  const SizedBox(
                    width: 10.0,
                  ),
                  IconButton(
                    padding: EdgeInsets.only(bottom: 10.0),
                    icon: Icon(FontAwesomeIcons.stamp),
                    iconSize: 40.0,
                    onPressed: () {},
                  ),
                  const SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                    icon: Icon(FontAwesomeIcons.star),
                    iconSize: 40.0,
                    onPressed: () {},
                  ),
                  const SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                    icon: Icon(FontAwesomeIcons.search),
                    iconSize: 40.0,
                    onPressed: () {},
                  ),
                  const SizedBox(
                    width: 50.0,
                  ),
                  IconButton(
                    icon: Icon(FontAwesomeIcons.userEdit),
                    iconSize: 40.0,
                    onPressed: () async {
                      final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ProfileEditPage(contact: contact)));
                      setState(() {
                        contact = result;
                      });
                    },
                  ),
                  const SizedBox(
                    width: 10.0,
                  ),
                ],
              ),
            ))
      ]),
    );
  }

  // Future<File> rotateAndCompressAndSaveImage(File image) async {
    /*int rotate = 0;
    List<int> imageBytes = await image.readAsBytes();
    Map<String, IfdTag> exifData = await readExifFromBytes(imageBytes);

    if (exifData != null &&
        exifData.isNotEmpty &&
        exifData.containsKey("Image Orientation")) {
      IfdTag orientation = exifData["Image Orientation"];
      int orientationValue = orientation.values[0];

      if (orientationValue == 3) {
        rotate = 180;
      }

      if (orientationValue == 6) {
        rotate = -90;
      }

      if (orientationValue == 8) {
        rotate = 90;
      }
    }

    List<int> result = await FlutterImageCompress.compressWithList(imageBytes,
        quality: 100, rotate: rotate);

    await image.writeAsBytes(result);

    return image;*/
  // }

}
